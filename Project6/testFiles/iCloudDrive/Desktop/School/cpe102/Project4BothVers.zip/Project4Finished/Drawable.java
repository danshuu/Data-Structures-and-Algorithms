/**
 * An interface that allows the previous classes to be drawable
 *
 * @author Bradley Ting, Daniel Shu
 * @version 11/4/2016
 */
public interface Drawable{
	public void draw();
}
